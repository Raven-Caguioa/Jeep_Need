package com.example.jeep_need

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.example.jeep_need.databinding.FragmentLoginBinding
import android.database.sqlite.SQLiteOpenHelper


class Login : Fragment() {
    private lateinit var binding: FragmentLoginBinding
    private lateinit var btSignin : ImageView
    private lateinit var tvSignUp : ImageView
    private lateinit var db: com.example.jeep_need.SQLiteOpenHelper

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentLoginBinding.inflate(inflater,container,false)

        binding.btSignIn.setOnClickListener {
            logindriver()
            loginpassenger()




        }
        binding.tvSignUp.setOnClickListener {
            findNavController().navigate(R.id.action_login_to_signup_choice)


        }

        return binding.root

    }
    private fun logindriver() {
        val email = binding.usernameSignIn.text.toString().trim()
        val password = binding.passwordSignIn.text.toString().trim()
        db = SQLiteOpenHelper(requireActivity())


        if (ValidationUtils.isTextNotEmpty(email) && ValidationUtils.isTextNotEmpty(password)) {
            if (ValidationUtils.isValidEmail(email)) {
                val isSuccess = db.logindriver(email, password)
                if (isSuccess) {
                    Toast.makeText(requireActivity(), "Log in!", Toast.LENGTH_SHORT).show()
                    findNavController().navigate(R.id.action_login_to_home)
                }
            } else {
                Toast.makeText(requireActivity(), "Invalid email!", Toast.LENGTH_SHORT).show()

            }
        } else {
            Toast.makeText(requireActivity(), "Enter all fields!", Toast.LENGTH_SHORT).show()
        }
    }
    private fun loginpassenger() {
        val email = binding.usernameSignIn.text.toString().trim()
        val password = binding.passwordSignIn.text.toString().trim()

        if (ValidationUtils.isTextNotEmpty(email) && ValidationUtils.isTextNotEmpty(password)) {
            if (ValidationUtils.isValidEmail(email)) {
                val isSuccess = db.loginpassenger(email, password)
                if (isSuccess) {
                    Toast.makeText(requireActivity(), "Log in!", Toast.LENGTH_SHORT).show()
                    findNavController().navigate(R.id.action_login_to_home)
                }
            } else {
                Toast.makeText(requireActivity(), "Invalid email!", Toast.LENGTH_SHORT).show()

            }
        } else {
            Toast.makeText(requireActivity(), "Enter all fields!", Toast.LENGTH_SHORT).show()
        }
    }
}
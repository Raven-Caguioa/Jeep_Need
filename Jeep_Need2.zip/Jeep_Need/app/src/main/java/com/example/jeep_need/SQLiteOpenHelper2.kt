package com.example.jeep_need

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import androidx.fragment.app.FragmentActivity

class SQLiteOpenHelper2(context: FragmentActivity): SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {
    companion object {
        private const val DATABASE_NAME = "acc.db"
        private const val DATABASE_VERSION = 1
        private const val Table_user = "passenger"

        private const val ID = "id"
        private const val NAME = "name"
        private const val PHONE = "phone"
        private const val EMAIL = "email"
        private const val PASSWORD = "password"
    }


    private val Create_Table = "Create Table $Table_user("+
            "$ID INTEGER PRIMARY KEY AUTOINCREMENT,"+
            "$NAME TEXT,"+
            "$PHONE INTEGER,"+
            "$EMAIL TEXT,"+
            "$PASSWORD TEXT)"
    private val Drop_Table = "DROP TABLE IF EXISTS $Table_user"



    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL(Create_Table)
    }

    override fun onUpgrade(db: SQLiteDatabase?, p1: Int, p2: Int) {
        db?.execSQL(Drop_Table)
    }

    fun loginpassenger(email: String, password: String):Boolean{
        val columns = arrayOf(ID)
        val db = this.readableDatabase
        val selection = "$EMAIL = ? AND $PASSWORD = ?"
        val selectionArgs = arrayOf(email,password)

        val cursor = db.query(
            Table_user,
            columns,
            selection,
            selectionArgs,
            null,
            null,
            null
        )
        val cursorCount = cursor.count
        cursor.close()
        db.close()
        return  cursorCount > 0

    }

    fun register(name: String, phone: String, email:String, password: String):Boolean{
        val db = this.writableDatabase
        val value = ContentValues()
        value.put(NAME,name)
        value.put(PHONE,phone)
        value.put(EMAIL,email)
        value.put(PASSWORD,password)

        db.insert(Table_user, null, value)
        db.close()
    return false
    }
}
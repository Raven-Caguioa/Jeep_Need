package com.example.jeep_need

data class User_Passenger (
    var id: Int = -1,
    var name: String = "",
    var phone: String = "",
    var email: String = "",
    var password: String = "",

    )